package com.example.lab_15

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
